import React , {useState , useEffect , useRef} from 'react';
import bgDesktopDark from './images/bg-desktop-dark.jpg';
import bgDesktopLight from './images/bg-desktop-light.jpg';
import iconSun from './images/icon-sun.svg';
import iconMoon from './images/icon-moon.svg';
import Form from './component/Form';
import TodoList from "./component/TodoList";



const App = () =>{

    const LOCAL_STORAGE_KEY = 'todos.key';

    const [inputText , setInputText] = useState("");
    const [todos , setTodos] = useState([]);
    // const [filters , setFilters] = useState('all');
    const [filterTodo , setFilterTodo] = useState([]);
    const [darkMode , setDarkMode] = useState(true);

    useEffect( () =>{
        const store = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
        if (store) setTodos(store);
    }, []);

    useEffect( () =>{
        localStorage.setItem(LOCAL_STORAGE_KEY , JSON.stringify(todos));
    }, [todos]);

    return(
        <div style={{minHeight:'100vh'}} className={darkMode ? 'darkmode' : 'lightmode'}>
          <header >
              <img className="h-72" src={darkMode ? bgDesktopDark : bgDesktopLight} alt="bg"/>
          </header>

          <div className="header container mx-auto flex items-center justify-between absolute inset-x-0 top-20 lg:w-2/5 sm:top-15 sm:w-3/5">
                <h1 className="text-white text-6xl text-left"> Todo</h1>
                <button onClick={() => setDarkMode(!darkMode)} ><img src={darkMode ? iconSun : iconMoon} alt="sun"/></button>
          </div>

        <Form
            todos={todos}
            setTodos={setTodos}
            setInputText={setInputText}
            inputText={inputText}
            // setFilters={setFilters}
            // filters={filters}
            setFilterTodo={setFilterTodo}
            darkMode={darkMode}

        />
        <TodoList
            todos={todos}
            setTodos={setTodos}
            filterTodo={filterTodo}
            darkMode={darkMode}
            // setFilters={setFilters}
            // filters={filters}
            setFilterTodo={setFilterTodo}
        />
        </div>
    )

};
export default App;
