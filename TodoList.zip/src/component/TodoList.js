import React , { useState , useEffect} from 'react';
import Todo from "./Todo";

const TodoList = ({todos , setTodos , filterTodo , darkMode ,setFilterTodo}) =>{

    {/*darkMode*/}
    const [active , setActive] = useState(1);

    const handleActive = (index) =>{
        setActive(index);
    };

    useEffect( () => {
        handleShowAll();
    }, [todos]);

    const handleShowAll =() =>{
        setFilterTodo(todos);
    };

    const handleFilterActive =() =>{
        setFilterTodo(todos.filter(todo => todo.complete === false));
    };

    const handleFilterComplete = () =>{
            setFilterTodo(todos.filter(todo => todo.complete === true));
    };
    const handleClearComplete =() =>{
        setTodos(todos.filter(todo => todo.complete === false));
    };

    return(
        <div >
            <ul className="todo-list relative inset-x-0 -top-8 sm:mt-15">
                {filterTodo.map((todo) =>(
                    <Todo
                        text={todo.text}
                        key={todo.id}
                        todos={todos}
                        setTodos={setTodos}
                        todo={todo}
                        filterTodo={filterTodo}
                        darkMode={darkMode}
                        // setFilters={setFilters}
                        // filters={filters}
                        setFilterTodo={setFilterTodo}
                    />
                ))}
                {todos.length > 0 ?(
                    <div className={` todo-footer text-sm container mx-auto lg:w-2/5 relative inset-x-0 bottom-0 sm:w-3/5 ${darkMode ? 'dark-footer' : 'light-footer'}`}>
                        <span className="text-gray-500 ">{todos.filter(todo => !todo.complete).length} items Left</span>
                        <div className="footer-items-in container mx-auto text-center inline space-x-4 ml-24 lg:ml-9 lg:space-x-2">
                            <button onClick={ () => {
                                handleActive(1);
                                handleShowAll()
                            }} onChange={handleShowAll}
                                    className={`hover-btn text-gray-500 text-center ${active === 1 ? 'active' : ''}`}>All
                            </button>
                            <button onClick={() => {
                                handleActive(2);
                                handleFilterActive()
                            }
                            } onChange={handleFilterActive}
                                    className={`hover-btn text-gray-500  ${active === 2 ? 'active' : ''}`}>Active
                            </button>
                            <button onClick={() => {
                                handleActive(3);
                                handleFilterComplete()
                            }}
                                    className={`hover-btn text-gray-500 ${active === 3 ? 'active' : ''}`}>Complete</button>
                        </div>

                        <button className=" hover-btn text-gray-500 float-right " onClick={handleClearComplete}>Clear Complete</button>
                    </div>

                ) : ''}

                {todos.length > 0 ?(
                    <div className={`footer-items container mx-auto text-center inline space-x-4 mx-20 ${darkMode ? 'dark-footer-items' : 'light-footer-items'}`}>
                        <button onClick={ () => {
                            handleActive(1);
                            handleShowAll()
                        }}
                                className={`hover-btn text-gray-500 text-center ${active === 1 ? 'active' : ''}`}>All
                        </button>
                        <button onClick={() => {
                            handleActive(2);
                            handleFilterActive()
                        }}
                                className={`hover-btn text-gray-500 ${active === 2 ? 'active' : ''}`}>Active
                        </button>
                        <button onClick={() => {
                                handleActive(3);
                                handleFilterComplete()
                            }}
                                className={`hover-btn text-gray-500 ${active === 3 ? 'active' : ''}`}>Complete</button>
                    </div>
                ): ''}

            </ul>
        </div>
    )

};
export default TodoList;