import React from 'react';
import crossIcon from '../images/icon-cross.svg';
import checkIcon from '../images/icon-check.svg';


const Todo =({text ,todo, todos , setTodos , darkMode}) =>{

    const handleDeleteTodo =() =>{
            setTodos(todos.filter((t) => t.id !== todo.id));
    };

    const handleCompleteTodo = () =>{
        setTodos(todos.map((item) =>{
            if(item.id === todo.id){
                return {...item , complete: !item.complete}
            }
            return item;
            }
        ));
    };

    return(
        <>
            <li className={`todo-items container mx-auto lg:w-2/5 relative sm:w-3/5 ${todo.complete && darkMode ? "dark-complete" : ""  } ${todo.complete && !darkMode ? "light-complete" : ""  } ${darkMode ? 'dark-list-item' : 'light-list-item'} `}>
                <button onClick={handleCompleteTodo} className={`border-gradient border-gradient-blue ${todo.complete ? "active" : "" } ${darkMode ? 'dark-check-btn' : 'light-check-btn'}`}>
                    <img src={checkIcon} alt="icon-check"/>
                </button>
                {text}
                <button className="cross-btn" onClick={handleDeleteTodo}><img src={crossIcon} alt="cross-icon"/></button>
            </li>


        </>
    );
};
export default Todo;