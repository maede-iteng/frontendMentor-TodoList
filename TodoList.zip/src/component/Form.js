import React from 'react';


const Form = ({setInputText , todos , setTodos , inputText , darkMode}) =>{


    const handleInputText = (e) =>{
        setInputText(e.target.value);
    };

    const handleAddTodo =(e) =>{
        e.preventDefault();
        if(inputText === '') return alert('please fill the form...');
        setTodos(
            [...todos , {text:inputText , complete:false , id: Math.random() * 1000}]);
        setInputText('');
    };

    return(
        <>
        <div className=" form-input container mx-auto lg:w-2/5 absolute inset-x-0 inset-y-2 mt-40 lg:mt-25 sm:w-3/5">
            <form action="" onSubmit={handleAddTodo} className="relative">
                <input  value={inputText} type="text" className={darkMode ? 'dark-input' : 'light-input'} onChange={handleInputText} placeholder='create a new todo...' />
                <button  className={`input-check-btn border-gradient border-gradient-blue ${darkMode ? 'input-dark-check-btn' : 'input-light-check-btn'} `}/>
            </form>
        </div>
        </>
    )
};
export default Form;